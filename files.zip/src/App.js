import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Chat from './components/Chat';
import UploadTestResults from './components/UploadTestResults';
import Learn from './pages/Learn';

function App() {
  return (
    <Router>
      <nav>
        <Link to="/">Chat</Link> | 
        <Link to="/upload">Upload Test Results</Link> | 
        <Link to="/learn">Learn</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Chat />} />
        <Route path="/upload" element={<UploadTestResults />} />
        <Route path="/learn" element={<Learn />} />
      </Routes>
    </Router>
  );
}

export default App;