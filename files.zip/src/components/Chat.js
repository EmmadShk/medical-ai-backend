// Replace with your deployed backend URL
const API_BASE_URL = "https://your-backend.onrender.com/api";
// ...
const response = await fetch(`${API_BASE_URL}/chat`, { ... });