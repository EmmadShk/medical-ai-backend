import React from 'react';

function Learn() {
  return (
    <div>
      <h2>Learn About Health Conditions</h2>
      <p>Coming soon: Educational resources about symptoms, conditions, and treatments.</p>
    </div>
  );
}

export default Learn;